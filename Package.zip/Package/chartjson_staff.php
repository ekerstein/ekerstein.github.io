<?php

$onGridLoadComplete = <<<ONGRIDLOADCOMPLETE
function ()
{
	function gridtoChart(ctype, cdate)
	{
	var data = $("#$grid_table").jqGrid('getRowData');
	
	var cdate2 = new Date(cdate).getTime();
	cdate2 = cdate2 - 1;
	cdate2 = new Date (cdate2);
	cdate2 = $.datepicker.formatDate('yy-mm-dd', cdate2);
	
	var results = jLinq.from(data)
	.equals("type",ctype)
	.lessDate("start_date",cdate)
	.greaterDate("end_date",cdate2)
	.count();
	
	return results;
	}
	
	var chartJSON = '[{"Month":"Jan","Associate":"'+
	gridtoChart("Associate", "2015-02-01")+
	'","BACS":"'+
	gridtoChart("BACS", "2015-02-01")+
	'","GDC On":"'+
	gridtoChart("GDC On", "2015-02-01")+
	'","GDC Off":"'+
	gridtoChart("GDC Off", "2015-02-01")+
	'","GDC Near":"'+
	gridtoChart("GDC Near", "2015-02-01")+
	'","TCMS":"'+
	gridtoChart("TCMS", "2015-02-01")+
	'","Consultant":"'+
	gridtoChart("Consultant", "2015-02-01")+
	
	'"},{"Month":"Feb","Associate":"'+
	gridtoChart("Associate", "2015-03-01")+
	'","BACS":"'+
	gridtoChart("BACS", "2015-03-01")+
	'","GDC On":"'+
	gridtoChart("GDC On", "2015-03-01")+
	'","GDC Off":"'+
	gridtoChart("GDC Off", "2015-03-01")+
	'","GDC Near":"'+
	gridtoChart("GDC Near", "2015-03-01")+
	'","TCMS":"'+
	gridtoChart("TCMS", "2015-03-01")+
	'","Consultant":"'+
	gridtoChart("Consultant", "2015-03-01")+
	
	'"},{"Month":"Mar","Associate":"'+
	gridtoChart("Associate", "2015-04-01")+
	'","BACS":"'+
	gridtoChart("BACS", "2015-04-01")+
	'","GDC On":"'+
	gridtoChart("GDC On", "2015-04-01")+
	'","GDC Off":"'+
	gridtoChart("GDC Off", "2015-04-01")+
	'","GDC Near":"'+
	gridtoChart("GDC Near", "2015-04-01")+
	'","TCMS":"'+
	gridtoChart("TCMS", "2015-04-01")+
	'","Consultant":"'+
	gridtoChart("Consultant", "2015-04-01")+
	
	'"},{"Month":"Apr","Associate":"'+
	gridtoChart("Associate", "2015-05-01")+
	'","BACS":"'+
	gridtoChart("BACS", "2015-05-01")+
	'","GDC On":"'+
	gridtoChart("GDC On", "2015-05-01")+
	'","GDC Off":"'+
	gridtoChart("GDC Off", "2015-05-01")+
	'","GDC Near":"'+
	gridtoChart("GDC Near", "2015-05-01")+
	'","TCMS":"'+
	gridtoChart("TCMS", "2015-05-01")+
	'","Consultant":"'+
	gridtoChart("Consultant", "2015-05-01")+
	
	'"},{"Month":"May","Associate":"'+
	gridtoChart("Associate", "2015-06-01")+
	'","BACS":"'+
	gridtoChart("BACS", "2015-06-01")+
	'","GDC On":"'+
	gridtoChart("GDC On", "2015-06-01")+
	'","GDC Off":"'+
	gridtoChart("GDC Off", "2015-06-01")+
	'","GDC Near":"'+
	gridtoChart("GDC Near", "2015-06-01")+
	'","TCMS":"'+
	gridtoChart("TCMS", "2015-06-01")+
	'","Consultant":"'+
	gridtoChart("Consultant", "2015-06-01")+
	
	'"},{"Month":"Jun","Associate":"'+
	gridtoChart("Associate", "2015-07-01")+
	'","BACS":"'+
	gridtoChart("BACS", "2015-07-01")+
	'","GDC On":"'+
	gridtoChart("GDC On", "2015-07-01")+
	'","GDC Off":"'+
	gridtoChart("GDC Off", "2015-07-01")+
	'","GDC Near":"'+
	gridtoChart("GDC Near", "2015-07-01")+
	'","TCMS":"'+
	gridtoChart("TCMS", "2015-07-01")+
	'","Consultant":"'+
	gridtoChart("Consultant", "2015-07-01")+
	
	'"},{"Month":"Jul","Associate":"'+
	gridtoChart("Associate", "2015-08-01")+
	'","BACS":"'+
	gridtoChart("BACS", "2015-08-01")+
	'","GDC On":"'+
	gridtoChart("GDC On", "2015-08-01")+
	'","GDC Off":"'+
	gridtoChart("GDC Off", "2015-08-01")+
	'","GDC Near":"'+
	gridtoChart("GDC Near", "2015-08-01")+
	'","TCMS":"'+
	gridtoChart("TCMS", "2015-08-01")+
	'","Consultant":"'+
	gridtoChart("Consultant", "2015-08-01")+
	
	'"},{"Month":"Aug","Associate":"'+
	gridtoChart("Associate", "2015-09-01")+
	'","BACS":"'+
	gridtoChart("BACS", "2015-09-01")+
	'","GDC On":"'+
	gridtoChart("GDC On", "2015-09-01")+
	'","GDC Off":"'+
	gridtoChart("GDC Off", "2015-09-01")+
	'","GDC Near":"'+
	gridtoChart("GDC Near", "2015-09-01")+
	'","TCMS":"'+
	gridtoChart("TCMS", "2015-09-01")+
	'","Consultant":"'+
	gridtoChart("Consultant", "2015-09-01")+
	
	'"},{"Month":"Sep","Associate":"'+
	gridtoChart("Associate", "2015-10-01")+
	'","BACS":"'+
	gridtoChart("BACS", "2015-10-01")+
	'","GDC On":"'+
	gridtoChart("GDC On", "2015-10-01")+
	'","GDC Off":"'+
	gridtoChart("GDC Off", "2015-10-01")+
	'","GDC Near":"'+
	gridtoChart("GDC Near", "2015-10-01")+
	'","TCMS":"'+
	gridtoChart("TCMS", "2015-10-01")+
	'","Consultant":"'+
	gridtoChart("Consultant", "2015-10-01")+
	
	'"},{"Month":"Oct","Associate":"'+
	gridtoChart("Associate", "2015-11-01")+
	'","BACS":"'+
	gridtoChart("BACS", "2015-11-01")+
	'","GDC On":"'+
	gridtoChart("GDC On", "2015-11-01")+
	'","GDC Off":"'+
	gridtoChart("GDC Off", "2015-11-01")+
	'","GDC Near":"'+
	gridtoChart("GDC Near", "2015-11-01")+
	'","TCMS":"'+
	gridtoChart("TCMS", "2015-11-01")+
	'","Consultant":"'+
	gridtoChart("Consultant", "2015-11-01")+
	
	'"},{"Month":"Nov","Associate":"'+
	gridtoChart("Associate", "2015-12-01")+
	'","BACS":"'+
	gridtoChart("BACS", "2015-12-01")+
	'","GDC On":"'+
	gridtoChart("GDC On", "2015-12-01")+
	'","GDC Off":"'+
	gridtoChart("GDC Off", "2015-12-01")+
	'","GDC Near":"'+
	gridtoChart("GDC Near", "2015-12-01")+
	'","TCMS":"'+
	gridtoChart("TCMS", "2015-12-01")+
	'","Consultant":"'+
	gridtoChart("Consultant", "2015-12-01")+
	
	'"},{"Month":"Dec","Associate":"'+
	gridtoChart("Associate", "2016-01-01")+
	'","BACS":"'+
	gridtoChart("BACS", "2016-01-01")+
	'","GDC On":"'+
	gridtoChart("GDC On", "2016-01-01")+
	'","GDC Off":"'+
	gridtoChart("GDC Off", "2016-01-01")+
	'","GDC Near":"'+
	gridtoChart("GDC Near", "2016-01-01")+
	'","TCMS":"'+
	gridtoChart("TCMS", "2016-01-01")+
	'","Consultant":"'+
	gridtoChart("Consultant", "2016-01-01")+
	'"}]';
	
	// TURN INTO JSON
	chartJSON = eval("(" + chartJSON + ')');
	
	// LOAD TO CHART
	chart.dataProvider = chartJSON;
	chart.validateData(); 
	
	//document.write(JSON.stringify(chartJSON));
	//document.write(chartJSON);
}
ONGRIDLOADCOMPLETE;

$grid->add_event("jqGridLoadComplete", $onGridLoadComplete);

?>