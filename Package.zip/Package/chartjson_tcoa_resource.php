<?php

$onGridLoadComplete = <<<ONGRIDLOADCOMPLETE
function ()
{
	function gridtoChart(eait,ehier)
	{ 
	var data = $("#$grid_table").jqGrid('getRowData');
	
	var carr = jLinq.from(data)
	.equals("ait_exec",eait)
	.equals("hier_exec",ehier)
  	.select();

	var csum = 0;
	for (var id in carr) {
    csum += parseFloat(carr[id].avg1);
	};
	
	return csum;
	}
	
	var chartJSON = '[{"Category":"Barker Apps ","Barker":"'+
	gridtoChart("Barker","Barker")+
	'","Calcanes":"'+
	gridtoChart("Barker","Calcanes")+
	'","Huff":"'+
	gridtoChart("Barker","Huff")+
	'","Chen":"'+
	gridtoChart("Barker","Chen")+
	'","Karafotis":"'+
	gridtoChart("Barker","Karafotis")+
	'","Yerra":"'+
	gridtoChart("Barker","Yerra")+
	'","Dilello":"'+
	gridtoChart("Barker","Dilello")+
	
	'"},{"Category":"Calcanes Apps","Barker":"'+
	gridtoChart("Calcanes","Barker")+
	'","Calcanes":"'+
	gridtoChart("Calcanes","Calcanes")+
	'","Huff":"'+
	gridtoChart("Calcanes","Huff")+
	'","Chen":"'+
	gridtoChart("Calcanes","Chen")+
	'","Karafotis":"'+
	gridtoChart("Calcanes","Karafotis")+
	'","Yerra":"'+
	gridtoChart("Calcanes","Yerra")+
	'","Dilello":"'+
	gridtoChart("Calcanes","Dilello")+
	
	'"},{"Category":"Huff Apps","Barker":"'+
	gridtoChart("Huff","Barker")+
	'","Calcanes":"'+
	gridtoChart("Huff","Calcanes")+
	'","Huff":"'+
	gridtoChart("Huff","Huff")+
	'","Chen":"'+
	gridtoChart("Huff","Chen")+
	'","Karafotis":"'+
	gridtoChart("Huff","Karafotis")+
	'","Yerra":"'+
	gridtoChart("Huff","Yerra")+
	'","Dilello":"'+
	gridtoChart("Huff","Dilello")+
	
	'"},{"Category":"Chen Apps","Barker":"'+
	gridtoChart("Chen","Barker")+
	'","Calcanes":"'+
	gridtoChart("Chen","Calcanes")+
	'","Huff":"'+
	gridtoChart("Chen","Huff")+
	'","Chen":"'+
	gridtoChart("Chen","Chen")+
	'","Karafotis":"'+
	gridtoChart("Chen","Karafotis")+
	'","Yerra":"'+
	gridtoChart("Chen","Yerra")+
	'","Dilello":"'+
	gridtoChart("Chen","Dilello")+
	
	'"},{"Category":"Karafotis Apps","Barker":"'+
	gridtoChart("Karafotis","Barker")+
	'","Calcanes":"'+
	gridtoChart("Karafotis","Calcanes")+
	'","Huff":"'+
	gridtoChart("Karafotis","Huff")+
	'","Chen":"'+
	gridtoChart("Karafotis","Chen")+
	'","Karafotis":"'+
	gridtoChart("Karafotis","Karafotis")+
	'","Yerra":"'+
	gridtoChart("Karafotis","Yerra")+
	'","Dilello":"'+
	gridtoChart("Karafotis","Dilello")+
	
	'"},{"Category":"Yerra Apps","Barker":"'+
	gridtoChart("Yerra","Barker")+
	'","Calcanes":"'+
	gridtoChart("Yerra","Calcanes")+
	'","Huff":"'+
	gridtoChart("Yerra","Huff")+
	'","Chen":"'+
	gridtoChart("Yerra","Chen")+
	'","Karafotis":"'+
	gridtoChart("Yerra","Karafotis")+
	'","Yerra":"'+
	gridtoChart("Yerra","Yerra")+
	'","Dilello":"'+
	gridtoChart("Yerra","Dilello")+
	
	'"},{"Category":"Dilello Apps ","Barker":"'+
	gridtoChart("Dilello","Barker")+
	'","Calcanes":"'+
	gridtoChart("Dilello","Calcanes")+
	'","Huff":"'+
	gridtoChart("Dilello","Huff")+
	'","Chen":"'+
	gridtoChart("Dilello","Chen")+
	'","Karafotis":"'+
	gridtoChart("Dilello","Karafotis")+
	'","Yerra":"'+
	gridtoChart("Dilello","Yerra")+
	'","Dilello":"'+
	gridtoChart("Dilello","Dilello")+
	'"}]';
	
	// TURN INTO JSON
	chartJSON = eval("(" + chartJSON + ')');
	
	// LOAD TO CHART
	chart.dataProvider = chartJSON;
	chart.validateData(); 
	
	//document.write(JSON.stringify(chartJSON));
	//document.write("TESTING");
}
ONGRIDLOADCOMPLETE;

$grid->add_event("jqGridLoadComplete", $onGridLoadComplete);

?>