<?php 

// SET GRID 'WHERE' FILTER
$grid -> set_query_filter("hier LIKE '$selected_hier'");  //use LIKE to include 4dots in roll-up

// SET REQUIRED COLUMNS (FOR EDITING)
$grid -> set_col_required("hier, person_num, name, type, start_date, end_date");

// SET EDIT PROPERTIES OF COLUMNS
$grid -> set_col_edittype("person_num", "text");
$grid -> set_col_edittype("name", "text");
$grid -> set_col_edittype("type", "select", "Associate:Associate;BACS:BACS;GDC On:GDC On;GDC Off:GDC Off;GDC Near:GDC Near;TCMS:TCMS;Consultant:Consultant");
$grid -> set_col_edittype("note", "text");

// CONDITIONAL FORMAT IF RESOURCE HAS LEFT OR NOT IN WFD

// SORT COLUMNS
$grid->set_sortname("hier ASC, type ASC, name", "ASC");

// SET COLUMN NAMES
$grid -> set_col_title("hier", "Hierarchy");
$grid -> set_col_title("person_num", "Person Number");
$grid -> set_col_title("type", "Resource Type");
$grid -> set_col_title("name", "Name");
$grid -> set_col_title("start_date", "Start Date");
$grid -> set_col_title("end_date", "End Date");
$grid -> set_col_title("note", "Notes");

// SET COLUMN WIDTH
$grid -> set_col_width("hier", 45);
$grid -> set_col_width("person_num", 60);
$grid -> set_col_width("type", 60);
$grid -> set_col_width("start_date", 55);
$grid -> set_col_width("end_date", 55);

?>