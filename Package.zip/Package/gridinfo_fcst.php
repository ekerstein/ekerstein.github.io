<?php

// SET GRID 'WHERE' FILTER
$grid -> set_query_filter("hier = '$selected_hier'");  //use = to exclude 4dots in roll-up

// UPDATE ASSOCIATE VALUES
$n_jan = "400000";
$n_feb = "4";
$n_mar = "4";
$n_apr = "4";
$n_may = "4";
$n_jun = "4";
$n_jul = "4";
$n_aug = "4";
$n_sep = "4";
$n_oct = "4";
$n_nov = "4";
$n_dec = "4";
$mysqli->query("UPDATE $grid_table SET jan1='$n_jan', feb1='$n_feb', mar1='$n_mar', apr1='$n_apr', may1='$n_may', jun1='$n_jun', jul1='$n_jul', aug1='$n_aug', sep1='$n_sep', oct1='$n_oct', nov1='$n_nov', dec1='$n_dec' WHERE account='Associate Salaries' AND hier='$selected_hier'");

// UPDATE DIRECT PROCESSING VALUES
function fcstDP($dp_month) {
	global $mysqli;
	global $selected_hier;
	$row = mysqli_fetch_row($mysqli->query("SELECT SUM($dp_month) FROM dp WHERE hier LIKE '$selected_hier'"));
	return $row[0];
}
$n_jan = fcstDP("jan1");
$n_feb = fcstDP("feb1");
$n_mar = fcstDP("mar1");
$n_apr = fcstDP("apr1");
$n_may = fcstDP("may1");
$n_jun = fcstDP("jun1");
$n_jul = fcstDP("jul1");
$n_aug = fcstDP("aug1");
$n_sep = fcstDP("sep1");
$n_oct = fcstDP("oct1");
$n_nov = fcstDP("nov1");
$n_dec = fcstDP("dec1");
$mysqli->query("UPDATE $grid_table SET jan1='$n_jan', feb1='$n_feb', mar1='$n_mar', apr1='$n_apr', may1='$n_may', jun1='$n_jun', jul1='$n_jul', aug1='$n_aug', sep1='$n_sep', oct1='$n_oct', nov1='$n_nov', dec1='$n_dec' WHERE account='Direct Processing' AND hier='$selected_hier'");

// SORT COLUMNS
$grid->set_sortname("account", "ASC");

// SET COLUMN NAMES
$grid -> set_col_title("hier", "Hierarchy");
$grid -> set_col_title("account", "Account");
$grid -> set_col_title("jan1", "Jan");
$grid -> set_col_title("feb1", "Feb");
$grid -> set_col_title("mar1", "Mar");
$grid -> set_col_title("apr1", "Apr");
$grid -> set_col_title("may1", "May");
$grid -> set_col_title("jun1", "Jun");
$grid -> set_col_title("jul1", "Jul");
$grid -> set_col_title("aug1", "Aug");
$grid -> set_col_title("sep1", "Sep");
$grid -> set_col_title("oct1", "Oct");
$grid -> set_col_title("nov1", "Nov");
$grid -> set_col_title("dec1", "Dec");

// SET COLUMN WIDTH
$grid -> set_col_width("hier", 25);
$grid -> set_col_width("account", 170);
$grid -> set_col_width("jan1", 25);
$grid -> set_col_width("feb1", 25);
$grid -> set_col_width("mar1", 25);
$grid -> set_col_width("apr1", 25);
$grid -> set_col_width("may1", 25);
$grid -> set_col_width("jun1", 25);
$grid -> set_col_width("jul1", 25);
$grid -> set_col_width("aug1", 25);
$grid -> set_col_width("sep1", 25);
$grid -> set_col_width("oct1", 25);
$grid -> set_col_width("nov1", 25);
$grid -> set_col_width("dec1", 25);

// SET CURRENCY TYPE
$grid -> set_col_currency("jan1", "$", "", ",",".", 0, "$0");
$grid -> set_col_currency("feb1", "$", "", ",",".", 0, "$0");
$grid -> set_col_currency("mar1", "$", "", ",",".", 0, "$0");
$grid -> set_col_currency("apr1", "$", "", ",",".", 0, "$0");
$grid -> set_col_currency("may1", "$", "", ",",".", 0, "$0");
$grid -> set_col_currency("jun1", "$", "", ",",".", 0, "$0");
$grid -> set_col_currency("jul1", "$", "", ",",".", 0, "$0");
$grid -> set_col_currency("aug1", "$", "", ",",".", 0, "$0");
$grid -> set_col_currency("sep1", "$", "", ",",".", 0, "$0");
$grid -> set_col_currency("oct1", "$", "", ",",".", 0, "$0");
$grid -> set_col_currency("nov1", "$", "", ",",".", 0, "$0");
$grid -> set_col_currency("dec1", "$", "", ",",".", 0, "$0");


?>