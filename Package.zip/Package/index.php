<?php 
require_once("phpGrid_Basic/conf.php"); 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>iForecast</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/css" href="stylesheet.css" />
<script src="amcharts/amcharts.js" type="text/javascript"></script>
<script src="amcharts/serial.js" type="text/javascript"></script>
<script src="amcharts/themes/light.js" type="text/javascript"></script>
<script src="jlinq.js" type="text/javascript"></script>
<!--
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
-->

</head>

<body>

<div id="wrapper">
<div id="header">
<div id="logo">iFORECAST</div>
<div id="buttons">

<?
$mysqli = new mysqli("localhost", "testuser", "test", "php_test");
$user = "nbkfgyo";

// select last_hier and last_table
$row = mysqli_fetch_row($mysqli->query("SELECT last_hier FROM last_select WHERE nbk='$user'"));
$selected_hier = $row[0];

$row = mysqli_fetch_row($mysqli->query("SELECT last_table FROM last_select WHERE nbk='$user'"));
$selected_table = $row[0];
//

// create Table dropdown
	// Pull list of tables user has access to
$t = $mysqli->query("SELECT DISTINCT tables.long FROM tables INNER JOIN hier ON tables.short=hier.access WHERE hier.nbk = '$user' ORDER BY tables.long");

echo "<form action=\"\" method=\"post\"><select id=\"tabledrop\" onchange=\"run()\" name=\"tabledrop\">"; 
echo "<option value='Table'>Table</option>";

while($row = mysqli_fetch_array($t)) 
	{ echo "<option value='".$row['long']."'>".$row['long']."</option>"; }
	
echo "</select>";
//

// create Hierarchy dropdown
$h = $mysqli->query("SELECT DISTINCT 4dot FROM hier WHERE nbk='$user' ORDER BY 4dot");

echo "<select id=\"hierdrop\" onchange=\"run()\" name=\"hierdrop\">"; 
echo "<option value='Hierarchy'>Hierarchy</option>";

while($row = mysqli_fetch_array($h)) 
	{ echo "<option value='".$row['4dot']."'>".$row['4dot']."</option>"; }

echo "</select>";
//

// create submit button and close form
echo "<input type=\"submit\" id=\"submit\" name=\"submit\" value=\"Go\" /></form>";
//

?>

</div>
</div>

<!-- submit button disable on "hierarchy" -->
<script type="text/javascript">
if(document.getElementById("tabledrop").value == "Table" && document.getElementById("hierdrop").value == "Hierarchy") {
	document.getElementById("submit").disabled = true; }
	
function run() {
	if(document.getElementById("tabledrop").value == "Table" && document.getElementById("hierdrop").value == "Hierarchy") {
	document.getElementById("submit").disabled = true; }
	else { document.getElementById("submit").disabled = false; }
}
</script>

<div id="current_hier">

<?

//get selected hier and table, exit if selected dropdown defaults (javascript backup)
if(isset($_POST['submit'])) 
{
	// Check if default or not then set variable
	if($_POST['tabledrop'] == "Table")
	{ $testt = $selected_table; }
	else
	{ $testt = $_POST['tabledrop']; }
	if($_POST['hierdrop'] == "Hierarchy") 
	{ $testh = $selected_hier; }
	else
	{ $testh = $_POST['hierdrop']; }
	// check if they have access for hierarchy they chose/last selected
	if(mysqli_num_rows($mysqli->query("SELECT hier.access FROM hier INNER JOIN tables ON hier.access=tables.short WHERE tables.long='$testt' AND nbk='$user' AND 4dot='$testh'")) <> 0)
	{
		if($_POST['hierdrop'] <> "Hierarchy") 
		{
			if($_POST['tabledrop'] <> "Table")
			{
			$selected_table = $_POST['tabledrop'];
			$selected_hier = $_POST['hierdrop'];
			echo strtoupper($selected_hier. " " .$selected_table);  
			$mysqli->query("UPDATE last_select SET last_table='$selected_table' WHERE nbk='$user'");
			$mysqli->query("UPDATE last_select SET last_hier='$selected_hier' WHERE nbk='$user'");
			}
			else
			{
			$selected_hier = $_POST['hierdrop'];
			echo strtoupper($selected_hier. " " .$selected_table);
			$mysqli->query("UPDATE last_select SET last_hier='$selected_hier' WHERE nbk='$user'");
			}
		}
		else 
		{
			if($_POST['tabledrop'] <> "Table")
			{
			$selected_table = $_POST['tabledrop'];
			echo strtoupper($selected_hier. " " .$selected_table);
			$mysqli->query("UPDATE last_select SET last_table='$selected_table' WHERE nbk='$user'");
			}
			else
			{
			echo "SELECT A HIERARCHY AND TABLE";
			exit ();
			}
		}
	}
	else
	{
	echo "YOU DO NOT HAVE ACCESS TO THAT TABLE / HIERARCHY COMBINATION";
	exit ();
	}
}
else
{
	// check if user still has access to last selection
	if(mysqli_num_rows($mysqli->query("SELECT hier.access FROM hier INNER JOIN tables ON hier.access=tables.short WHERE tables.long='$selected_table' AND nbk='$user' AND 4dot='$selected_hier'")) <> 0)
	{ echo strtoupper($selected_hier. " " .$selected_table); }
	else
	{  echo "YOU DO NOT HAVE ACCESS TO THAT TABLE / HIERARCHY COMBINATION";
	exit (); }
}
//     

?>

</div>

<?

//find table name
$row = mysqli_fetch_row($mysqli->query("SELECT tables.short FROM tables INNER JOIN hier ON tables.short=hier.access WHERE tables.long='$selected_table' AND nbk='$user' AND 4dot='$selected_hier'"));
$grid_table = $row[0];

// CREATE GRID
$grid_query = "SELECT * FROM ".$grid_table;
$grid = new C_DataGrid("$grid_query","id","$grid_table");

// Determine access
$row = mysqli_fetch_row($mysqli->query("SELECT hier.edit FROM hier INNER JOIN tables ON hier.access=tables.short WHERE tables.long='$selected_table' AND nbk='$user' AND 4dot='$selected_hier'")); 
$grid_edit = $row[0];

$grid -> enable_edit('FORM', $grid_edit);

// Make editable their hierarchies only, "VMP_" would have all VMP 4dots. Forecast table is excluded.
if($grid_table <> "fcst") 
{
$t = $mysqli->query("SELECT 4dot FROM hier WHERE nbk='$user' AND 4dot LIKE '$selected_hier' AND access='$grid_table' AND (4dot<>'VMP_') UNION SELECT hier FROM $grid_table WHERE hier LIKE '$selected_hier' AND (hier<>'VMP_') ORDER BY 4dot");

	//make string and cut it
$s = "";
while($row = mysqli_fetch_array($t)) { 
	$s = $s . $row['4dot'].":".$row['4dot'].";"; }
$t = substr($s,0,-1);
$grid -> set_col_edittype("hier", "select", "$t");
}

// SET GRID DIMENSIONS (second is height)
$grid -> set_dimension("100%", 331, true);

// OTHER Grid properties
		//$grid -> set_grid_property(array('multiselect'=>false));
		//$grid -> cust_prop_jsonstr = 'toppager:true,'; // moves edit bar to top
		//$grid -> set_col_hidden('hier', false); still edits correctly!
		//$grid -> enable_advanced_search(true);
$grid -> set_grid_property(array('forceFit'=>true));
$grid -> set_grid_property(array('autowidth'=>true));
$grid -> set_grid_property(array('altRows'=>false));
$grid -> enable_export('EXCEL');
$grid -> set_grid_property(array('scroll'=>true));
$grid -> set_grid_property(array('rowNum'=>10000));
$grid -> set_grid_property(array('rownumbers'=>true));
$grid -> set_grid_property(array('rownumWidth'=>19));
$grid -> set_grid_property(array('scrollOffset'=>12));
$grid -> set_grid_property(array('sortable'=>false));
$grid -> set_grid_property(array('gridview'=>true)); //can't use some features if true -- subgrid, treegrid
$grid -> set_grid_property(array('treeGrid'=>false));
$grid -> enable_resize(false);
$grid -> enable_search(true);
$grid -> set_col_hidden('id', false);
$grid -> set_caption('');

// BRING IN TABLE-SPECIFIC SETTINGS
if($grid_table == "staff")
{ include 'gridinfo_staff.php'; }
if($grid_table == "dp")
{ include 'gridinfo_dp.php'; }
if($grid_table == "fcst")
{ include 'gridinfo_fcst.php'; }
if($grid_table == "tcoa_resource")
{ include 'gridinfo_tcoa_resource.php'; }

?>

<!-- chart made inside div -->
<div id="chart">
<div id="chartdiv"></div>	
</div>
<div id="content">

<?

// Bring in chart JSON on data refresh
if($grid_table == "staff")
{ include 'chartjson_staff.php'; }
if($grid_table == "dp")
{ include 'chartjson_dp.php'; }
if($grid_table == "tcoa_resource")
{ include 'chartjson_tcoa_resource.php'; }

// DISPLAY GRID
$grid -> display();

//Include Javascript information for charts
if($grid_table == "staff")
{ include 'chartinfo_staff.php'; }
if($grid_table == "dp")
{ include 'chartinfo_dp.php'; }
if($grid_table == "tcoa_resource")
{ include 'chartinfo_tcoa_resource.php'; }

?>

</div>	
</div>

</body>
</html>