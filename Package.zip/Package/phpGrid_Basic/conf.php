<?php
// mysql example

define('PHPGRID_DB_HOSTNAME','localhost'); // database host name
define('PHPGRID_DB_USERNAME', 'testuser');     // database user name
define('PHPGRID_DB_PASSWORD', 'test'); // database password
define('PHPGRID_DB_NAME', 'php_test'); // database name
define('PHPGRID_DB_TYPE', 'mysql');  // database type
define('PHPGRID_DB_CHARSET','utf8'); // ex: utf8(for mysql),AL32UTF8 (for oracle), leave blank to use the default charset

define('THEME', 'start');
define('DEBUG', false); // *** MUST SET TO FALSE WHEN DEPLOYED IN PRODUCTION ***

define('SERVER_ROOT', str_replace(realpath($_SERVER['DOCUMENT_ROOT']),'', str_replace('\\', '/',dirname(__FILE__))));

/******** DO NOT MODIFY ***********/
require_once('phpGrid.php');     
/**********************************/
?>
