<script type="text/javascript">

// SET CURRENT FORECAST MONTH (FOR forecast lines)
var curMonth = "Jul"

/* TEST LOAD
var loadME = [];
    loadME.push({"Month":"Jan","Amount":"20"});
*/

var chart = AmCharts.makeChart("chartdiv", {
        "dataProvider": [],
		"type": "serial",
		"theme": "light",
        "pathToImages": "amcharts/images/",
		"precision": 1, //decimals
		"autoMargins": true,
		/*
		"legend": {
        			"horizontalGap": 1,
        			"maxColumns": 1,
        			"position": "right",
					"useGraphSettings": true,
					"markerSize": 10,
					"reversedOrder": true,
					"autoMargins": false,
					"marginLeft": -12,
					"marginRight": 20,
					"valueText": ""
    			  },
		*/
		"chartCursor": {
					"animationDuration": 0.15,
					"categoryBalloonEnabled": false,
					"fullWidth": true,
					"cursorAlpha": .09,
					"zoomable": false
					},
		"balloon": {
					"animationDuration": 0.15,
					"borderThickness": 1.3,
					"fontSize": 10,
					"horizontalPadding": 4,
					"verticalPadding": 2,
					"fillAlpha": 1,
					"pointerWidth": 20
					//"cornerRadius": 2, // DOESNT WORK WITH POINTER	
				  },
        "valueAxes": [{
        			"stackType": "regular",
        			"axisAlpha": 0.3,
        			"gridAlpha": 0,
					//"totalText": "[[total]]",
					"axisThickness": 0,
					"tickLength": 0,
					"ignoreAxisWidth": true,
					"labelsEnabled": false
    				 }],
		"categoryAxis": {
        			"gridPosition": "start",
        			"axisAlpha": 1,
        			"gridAlpha": 0,
					"tickLength": 0,
    					},
		
		"graphs": [{
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "$[[value]]",
        "lineThickness": 0,
        "title": "Amount",
        "type": "column",
		"color": "#000000",
        "valueField": "Amount",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "$" + info.values.value;
			else
			return ''; }
    }],
	
		"categoryField": "Month",			 
		"guides": [{
			"category": curMonth,
			"toCategory": "Dec",
			"dashLength": 5,
			"expand": true,
			"inside": true,
			"label": "Forecast",
			"lineAlpha": 1,
			"fillAlpha": .04,
			"position": "top"
		}],
		"exportConfig":{
						"menuTop":"20px",
        				"menuRight":"20px",
        				"menuItems": [{
        				"icon": '/amcharts/images/export.png',
        				"format": 'png'	  
        			 				 }]  
    				    }
});


// GRID SETTING - ALWAYS DISPLAY INTEGRATED SEARCH IN GRID
$(function() {
    var grid = jQuery(dp);
    grid[0].toggleToolbar();
});

</script>