<script type="text/javascript">

/* TEST LOAD
var loadME = [];
    loadME.push({"Category":"Barker Apps#","Barker":"20","Calcanes":"6","Huff":"2","Chen":"1","Karafotis":"2","Yerra":"1","Dilello":"2"});
*/

var chart = AmCharts.makeChart("chartdiv", {
        "dataProvider": [],
		"type": "serial",
		"theme": "light",
        "pathToImages": "amcharts/images/",
		"autoMargins": true,
		"precision": 0,
		"legend": {
        			"horizontalGap": 1,
        			"maxColumns": 1,
        			"position": "right",
					"useGraphSettings": true,
					"markerSize": 10,
					"reversedOrder": true,
					"autoMargins": false,
					"marginLeft": -12,
					"marginRight": 20,
					"valueText": ""
    			  },
		"chartCursor": {
					"animationDuration": 0.15,
					"categoryBalloonEnabled": false,
					"fullWidth": true,
					"cursorAlpha": .09,
					"zoomable": false
					},
		"balloon": {
					"animationDuration": 0.15,
					"borderThickness": 1.3,
					"fontSize": 10,
					"horizontalPadding": 4,
					"verticalPadding": 2,
					"fillAlpha": 1,
					"pointerWidth": 20
					//"cornerRadius": 2, // DOESNT WORK WITH POINTER	
				  },	  
        "valueAxes": [{
        			"stackType": "regular",
        			"axisAlpha": 0.3,
        			"gridAlpha": 0,
					"totalText": "[[total]]",
					"axisThickness": 0,
					"tickLength": 0,
					"ignoreAxisWidth": true,
					"labelsEnabled": false
    				 }],
		"categoryAxis": {
        			"gridPosition": "start",
					"autoWrap": true,
        			"axisAlpha": 1,
        			"gridAlpha": 0,
					"tickLength": 0,
    					},
		
		"graphs": [{
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "Barker",
        "type": "column",
		"color": "#000000",
        "valueField": "Barker",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "Barker: " + info.values.value;
			else
			return ''; }	
    }, {
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "Calcanes",
        "type": "column",
		"color": "#000000",
        "valueField": "Calcanes",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "Calcanes: " + info.values.value;
			else
			return ''; }	
    }, {
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "Huff",
        "type": "column",
		"color": "#000000",
        "valueField": "Huff",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "Huff: " + info.values.value;
			else
			return ''; }		
    }, {
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "Chen",
        "type": "column",
		"color": "#000000",
        "valueField": "Chen",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "Chen: " + info.values.value;
			else
			return ''; }		
    }, {
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "Karafotis",
        "type": "column",
		"color": "#000000",
        "valueField": "Karafotis",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "Karafotis: " + info.values.value;
			else
			return ''; }		
    }, {
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "Yerra",
        "type": "column",
		"color": "#000000",
        "valueField": "Yerra",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "Yerra: " + info.values.value;
			else
			return ''; }	
    }, {
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "Dilello",
        "type": "column",
		"color": "#000000",
		"fillColors": "#FF8000",
        "valueField": "Dilello",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "Dilello: " + info.values.value;
			else
			return ''; }	
    }],
	
		"categoryField": "Category",			 
		/*
		"guides": [{
			"category": "Barker Apps ",
			"toCategory": "Dilello Apps ",
			"dashLength": 0, // was 5
			"expand": true,
			"inside": true,
			//"fontSize": 12,
			"label": "Associates",
			"lineAlpha": 1,
			"fillAlpha": 0, // was .04
			"position": "top"
		},
		{
			"category": "Barker Apps",
			"toCategory": "Dilello Apps",
			"dashLength": 0, // was 5
			"expand": true,
			"inside": true,
			//"fontSize": 12,
			"label": "BACS/GDC/TCMS",
			"lineAlpha": 1,
			"fillAlpha": 0, // was .04
			"position": "top"
		}],
		*/
		"exportConfig":{
						"menuTop":"20px",
        				"menuRight":"20px",
        				"menuItems": [{
        				"icon": '/amcharts/images/export.png',
        				"format": 'png'	  
        			 				 }]  
    				    }
});


// GRID SETTING - ALWAYS DISPLAY INTEGRATED SEARCH IN GRID
$(function() {
    var grid = jQuery(tcoa_resource);
    grid[0].toggleToolbar();
});

</script>