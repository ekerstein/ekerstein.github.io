<script type="text/javascript">

// SET CURRENT FORECAST MONTH (FOR forecast lines)
var curMonth = "Jul"

/* TEST LOAD
var loadME = [];
    loadME.push({"Month":"Jan","Associate":"20","BACS":"6","GDC On":"2","GDC Off":"1","GDC Near":"2","TCMS":"1","Consultant":"2"});
*/

var chart = AmCharts.makeChart("chartdiv", {
        "dataProvider": [],
		"type": "serial",
		"theme": "light",
        "pathToImages": "amcharts/images/",
		"autoMargins": true,
		"precision": 0,
		"legend": {
        			"horizontalGap": 1,
        			"maxColumns": 1,
        			"position": "right",
					"useGraphSettings": true,
					"markerSize": 10,
					"reversedOrder": true,
					"autoMargins": false,
					"marginLeft": -12,
					"marginRight": 20,
					"valueText": ""
    			  },
		"chartCursor": {
					"animationDuration": 0.15,
					"categoryBalloonEnabled": false,
					"fullWidth": true,
					"cursorAlpha": .09,
					"zoomable": false
					},
		"balloon": {
					"animationDuration": 0.15,
					"borderThickness": 1.3,
					"fontSize": 10,
					"horizontalPadding": 4,
					"verticalPadding": 2,
					"fillAlpha": 1,
					"pointerWidth": 20
					//"cornerRadius": 2, // DOESNT WORK WITH POINTER	
				  },	  
        "valueAxes": [{
        			"stackType": "regular",
        			"axisAlpha": 0.3,
        			"gridAlpha": 0,
					"totalText": "[[total]]",
					"axisThickness": 0,
					"tickLength": 0,
					"ignoreAxisWidth": true,
					"labelsEnabled": false
    				 }],
		"categoryAxis": {
        			"gridPosition": "start",
        			"axisAlpha": 1,
        			"gridAlpha": 0,
					"tickLength": 0,
    					},
		
		"graphs": [{
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "Associate",
        "type": "column",
		"color": "#000000",
        "valueField": "Associate",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "Associate: " + info.values.value;
			else
			return ''; }	
    }, {
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "BACS",
        "type": "column",
		"color": "#000000",
        "valueField": "BACS",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "BACS: " + info.values.value;
			else
			return ''; }	
    }, {
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "GDC On",
        "type": "column",
		"color": "#000000",
        "valueField": "GDC On",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "GDC On: " + info.values.value;
			else
			return ''; }		
    }, {
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "GDC Off",
        "type": "column",
		"color": "#000000",
        "valueField": "GDC Off",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "GDC Off: " + info.values.value;
			else
			return ''; }		
    }, {
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "GDC Near",
        "type": "column",
		"color": "#000000",
        "valueField": "GDC Near",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "GDC Near: " + info.values.value;
			else
			return ''; }		
    }, {
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "TCMS",
        "type": "column",
		"color": "#000000",
        "valueField": "TCMS",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "TCMS: " + info.values.value;
			else
			return ''; }	
    }, {
        //"balloonText": "[[title]]: [[value]]",
		"dashLengthField": "dashLengthColumn",
		"alphaField": "alpha",
        "fillAlphas": .8,
        "labelText": "[[value]]",
        "lineThickness": 0,
        "title": "Consultant",
        "type": "column",
		"color": "#000000",
		"fillColors": "#FF8000",
        "valueField": "Consultant",
		"balloonFunction": function (info) {
			if (info.values.value)
			return "Consultant: " + info.values.value;
			else
			return ''; }	
    }],
	
		"categoryField": "Month",			 
		"guides": [{
			"category": curMonth,
			"toCategory": "Dec",
			"dashLength": 5,
			"expand": true,
			"inside": true,
			"label": "Forecast",
			"lineAlpha": 1,
			"fillAlpha": .04,
			"position": "top"
		}],
		"exportConfig":{
						"menuTop":"20px",
        				"menuRight":"20px",
        				"menuItems": [{
        				"icon": '/amcharts/images/export.png',
        				"format": 'png'	  
        			 				 }]  
    				    }
});


// GRID SETTING - ALWAYS DISPLAY INTEGRATED SEARCH IN GRID
$(function() {
    var grid = jQuery(staff);
    grid[0].toggleToolbar();
});

</script>