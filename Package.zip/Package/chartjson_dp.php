<?php

$onGridLoadComplete = <<<ONGRIDLOADCOMPLETE
function ()
{
	function gridtoChart(cmonth)
	{
	var data = $("#$grid_table").jqGrid('getRowData');
	
	var carr = jLinq.from(data)
	.not().equals(cmonth,0)
	.andNot("0.0")
  	.select();

	var csum = 0;
	for (var id in carr) {
    csum += parseFloat(carr[id][cmonth]);
	};
	
	return csum;
	}
	
	var chartJSON = '[{"Month":"Jan","Amount":"'+
	gridtoChart("jan1")+
	'"},{"Month":"Feb","Amount":"'+
	gridtoChart("feb1")+
	'"},{"Month":"Mar","Amount":"'+
	gridtoChart("mar1")+
	'"},{"Month":"Apr","Amount":"'+
	gridtoChart("apr1")+
	'"},{"Month":"May","Amount":"'+
	gridtoChart("may1")+
	'"},{"Month":"Jun","Amount":"'+
	gridtoChart("jun1")+
	'"},{"Month":"Jul","Amount":"'+
	gridtoChart("jul1")+
	'"},{"Month":"Aug","Amount":"'+
	gridtoChart("aug1")+
	'"},{"Month":"Sep","Amount":"'+
	gridtoChart("sep1")+
	'"},{"Month":"Oct","Amount":"'+
	gridtoChart("oct1")+
	'"},{"Month":"Nov","Amount":"'+
	gridtoChart("nov1")+
	'"},{"Month":"Dec","Amount":"'+
	gridtoChart("dec1")+
	'"}]';
	
	// TURN INTO JSON
	chartJSON = eval("(" + chartJSON + ')');
	
	// LOAD TO CHART
	chart.dataProvider = chartJSON;
	chart.validateData(); 
	
	//document.write(JSON.stringify(csum));
	//document.write(carr);
}
ONGRIDLOADCOMPLETE;

$grid->add_event("jqGridLoadComplete", $onGridLoadComplete);

?>