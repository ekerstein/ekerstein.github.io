<?php 

// SET GRID 'WHERE' FILTER
$grid -> set_query_filter("hier LIKE '$selected_hier'");  //use LIKE to include 4dots in roll-up

// SET REQUIRED COLUMNS (FOR EDITING)
$grid -> set_col_required("hier, ait");

// SET EDIT PROPERTIES OF COLUMNS
$grid -> set_col_edittype("type", "select", "Associate:Associate;BACS/GDC/TCMS:BACS/GDC/TCMS");
$grid -> set_col_edittype("hier_exec", "select", "Barker:Barker;Calcanes:Calcanes;Huff:Huff;Chen:Chen;Karafotis:Karafotis;Yerra:Yerra;Dilello:Dilello");
$grid -> set_col_edittype("ait_exec", "select", "Barker:Barker;Calcanes:Calcanes;Huff:Huff;Chen:Chen;Karafotis:Karafotis;Yerra:Yerra;Dilello:Dilello");

// HIDE COLUMNS FROM EDIT FORM
$grid -> set_col_property('hier_exec', array('editable'=>false,'hidedlg'=>true));
$grid -> set_col_property('ait_exec', array('editable'=>false,'hidedlg'=>true));
$grid -> set_col_property('avg1', array('editable'=>false,'hidedlg'=>true));

// SORT COLUMNS
$grid->set_sortname("hier ASC, ait ASC, type", "ASC");

// SET COLUMN NAMES
$grid -> set_col_title("hier", "Hierarchy");
$grid -> set_col_title("hier_exec", "Hier Exec");
$grid -> set_col_title("type", "Resource Type");
$grid -> set_col_title("ait", "AIT");
$grid -> set_col_title("ait_exec", "AIT Exec");
$grid -> set_col_title("jan1", "Jan");
$grid -> set_col_title("feb1", "Feb");
$grid -> set_col_title("mar1", "Mar");
$grid -> set_col_title("apr1", "Apr");
$grid -> set_col_title("may1", "May");
$grid -> set_col_title("jun1", "Jun");
$grid -> set_col_title("jul1", "Jul");
$grid -> set_col_title("aug1", "Aug");
$grid -> set_col_title("sep1", "Sep");
$grid -> set_col_title("oct1", "Oct");
$grid -> set_col_title("nov1", "Nov");
$grid -> set_col_title("dec1", "Dec");
$grid -> set_col_title("avg1", "Average");

// SET COLUMN WIDTH
$grid -> set_col_width("hier", 35);
$grid -> set_col_width("hier_exec", 50);
$grid -> set_col_width("type", 80);
$grid -> set_col_width("ait", 40);
$grid -> set_col_width("ait_exec", 50);
$grid -> set_col_width("jan1", 30);
$grid -> set_col_width("feb1", 30);
$grid -> set_col_width("mar1", 30);
$grid -> set_col_width("apr1", 30);
$grid -> set_col_width("may1", 30);
$grid -> set_col_width("jun1", 30);
$grid -> set_col_width("jul1", 30);
$grid -> set_col_width("aug1", 30);
$grid -> set_col_width("sep1", 30);
$grid -> set_col_width("oct1", 30);
$grid -> set_col_width("nov1", 30);
$grid -> set_col_width("dec1", 30);
$grid -> set_col_width("avg1", 40);

// SET NULL TO SHOW 0.0 (OR REFRESH)
$grid -> set_col_currency("jan1", "", "", ",",".", 1, "0.0");
$grid -> set_col_currency("feb1", "", "", ",",".", 1, "0.0");
$grid -> set_col_currency("mar1", "", "", ",",".", 1, "0.0");
$grid -> set_col_currency("apr1", "", "", ",",".", 1, "0.0");
$grid -> set_col_currency("may1", "", "", ",",".", 1, "0.0");
$grid -> set_col_currency("jun1", "", "", ",",".", 1, "0.0");
$grid -> set_col_currency("jul1", "", "", ",",".", 1, "0.0");
$grid -> set_col_currency("aug1", "", "", ",",".", 1, "0.0");
$grid -> set_col_currency("sep1", "", "", ",",".", 1, "0.0");
$grid -> set_col_currency("oct1", "", "", ",",".", 1, "0.0");
$grid -> set_col_currency("nov1", "", "", ",",".", 1, "0.0");
$grid -> set_col_currency("dec1", "", "", ",",".", 1, "0.0");
$grid -> set_col_currency("avg1", "", "", ",",".", 1, "Refresh");

// CREATE TEMPORARY TABLE FROM TCOA TABLE (WITH AVERAGE COLUMN)
$mysqli->query("CREATE TEMPORARY TABLE IF NOT EXISTS tcoa_avg ENGINE=MEMORY AS (SELECT id, ((IFNULL(jan1,0)+IFNULL(feb1,0)+IFNULL(mar1,0)+IFNULL(apr1,0)+IFNULL(may1,0)+IFNULL(jun1,0)+IFNULL(jul1,0)+IFNULL(aug1,0)+IFNULL(sep1,0)+IFNULL(oct1,0)+IFNULL(nov1,0)+IFNULL(dec1,0))/12) AS avg1 FROM tcoa_resource)");

// UPDATE TCOA TABLE WITH AVERAGE FROM TEMPORARY TABLE
$mysqli->query("UPDATE tcoa_resource INNER JOIN tcoa_avg ON tcoa_resource.id=tcoa_avg.id SET tcoa_resource.avg1 = tcoa_avg.avg1");

// UPDATE TCOA TABLE WITH AIT EXEC FROM AIT DATA
$mysqli->query("UPDATE tcoa_resource INNER JOIN ait_data ON tcoa_resource.ait=ait_data.ait SET tcoa_resource.ait_exec = ait_data.exec");

// UPDATE TCOA TABLE WITH RESOURCE EXEC FROM HIER DATA
$mysqli->query("UPDATE tcoa_resource INNER JOIN hier_data ON tcoa_resource.hier LIKE hier_data.hier SET tcoa_resource.hier_exec = hier_data.exec");


?>