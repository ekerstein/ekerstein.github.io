<?php 

// SET GRID 'WHERE' FILTER
$grid -> set_query_filter("hier LIKE '$selected_hier'");  //use LIKE to include 4dots in roll-up

// SET REQUIRED COLUMNS (FOR EDITING)
$grid -> set_col_required("hier, vendor");

// SORT COLUMNS
$grid->set_sortname("hier ASC, vendor", "ASC");

// SET EDIT PROPERTIES OF COLUMNS
//$grid -> set_col_edittype("vendor", "autocomplete");

// HIDE COLUMNS (FALSE REMOVES FROM FORM)
$grid -> set_col_hidden("jan2", false);
$grid -> set_col_hidden("feb2", false);
$grid -> set_col_hidden("mar2", false);
$grid -> set_col_hidden("apr2", false);
$grid -> set_col_hidden("may2", false);
$grid -> set_col_hidden("jun2", false);
$grid -> set_col_hidden("jul2", false);
$grid -> set_col_hidden("aug2", false);
$grid -> set_col_hidden("sep2", false);
$grid -> set_col_hidden("oct2", false);
$grid -> set_col_hidden("nov2", false);
$grid -> set_col_hidden("dec2", false);

// SET COLUMN NAMES
$grid -> set_col_title("hier", "Hierarchy");
$grid -> set_col_title("vendor", "Vendor");
$grid -> set_col_title("ait", "AIT");
$grid -> set_col_title("jan1", "Jan");
$grid -> set_col_title("feb1", "Feb");
$grid -> set_col_title("mar1", "Mar");
$grid -> set_col_title("apr1", "Apr");
$grid -> set_col_title("may1", "May");
$grid -> set_col_title("jun1", "Jun");
$grid -> set_col_title("jul1", "Jul");
$grid -> set_col_title("aug1", "Aug");
$grid -> set_col_title("sep1", "Sep");
$grid -> set_col_title("oct1", "Oct");
$grid -> set_col_title("nov1", "Nov");
$grid -> set_col_title("dec1", "Dec");
$grid -> set_col_title("note", "Notes");

// SET COLUMN WIDTH
$grid -> set_col_width("hier", 60);
$grid -> set_col_width("vendor", 110);
$grid -> set_col_width("ait", 40);
$grid -> set_col_width("jan1", 35);
$grid -> set_col_width("feb1", 35);
$grid -> set_col_width("mar1", 35);
$grid -> set_col_width("apr1", 35);
$grid -> set_col_width("may1", 35);
$grid -> set_col_width("jun1", 35);
$grid -> set_col_width("jul1", 35);
$grid -> set_col_width("aug1", 35);
$grid -> set_col_width("sep1", 35);
$grid -> set_col_width("oct1", 35);
$grid -> set_col_width("nov1", 35);
$grid -> set_col_width("dec1", 35);

// SET CURRENCY TYPE
// $grid -> set_col_currency("jan1", "$", "", ",",".", 1, "0");



?>